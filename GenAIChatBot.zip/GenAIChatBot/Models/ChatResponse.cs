// using System.Text.Json.Serialization;

// public class ChatResponse
// {
//     [JsonPropertyName("answer")]
//     public string Answer { get; set; }
// }

namespace GenAIChatBot.Models
{
    public class ChatResponse
    {
        public string Answer { get; set; }
        public string Designation { get; set; }  // Added this

        public bool FromCache { get; set; }  //Indicates if answer came from Redis cache
    }
}
