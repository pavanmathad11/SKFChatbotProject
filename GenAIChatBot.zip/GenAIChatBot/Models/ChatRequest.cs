// namespace GenAIChatBot.Models
// {
//     public class ChatRequest
//     {
//         public string Question { get; set; }
//         public string LastDesignation { get; set; }
//     }
// }


using System.Text.Json.Serialization;
//namespace GenAIChatBot.Models
public class ChatRequest
{
    [JsonPropertyName("question")]
    public string Question { get; set; }

    [JsonPropertyName("lastDesignation")]
    public string LastDesignation { get; set; }
}