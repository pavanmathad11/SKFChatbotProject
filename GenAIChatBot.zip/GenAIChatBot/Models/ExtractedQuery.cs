namespace GenAIChatBot.Models
{
    public class ExtractedQuery
    {
        public string Designation { get; set; }
        public string Attribute { get; set; }
    }
}