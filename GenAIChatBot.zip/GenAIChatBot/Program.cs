using System;
using Azure;
using Azure.AI.OpenAI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace GenAIChatBot
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var host = new HostBuilder()
                .ConfigureFunctionsWorkerDefaults()
                .ConfigureServices(services =>
                {
                    var openAiEndpoint = Environment.GetEnvironmentVariable("AZURE_OPENAI_ENDPOINT")
                                        ?? throw new InvalidOperationException("AZURE_OPENAI_ENDPOINT is missing.");

                    var openAiKey = Environment.GetEnvironmentVariable("AZURE_OPENAI_API_KEY")
                                    ?? throw new InvalidOperationException("AZURE_OPENAI_API_KEY is missing.");

                    var openAiDeployment = Environment.GetEnvironmentVariable("AZURE_OPENAI_DEPLOYMENT")
                                           ?? throw new InvalidOperationException("AZURE_OPENAI_DEPLOYMENT is missing.");

                    var openAiClient = new OpenAIClient(
                        new Uri(openAiEndpoint),
                        new AzureKeyCredential(openAiKey)
                    );

                    services.AddSingleton(openAiClient);

                    // FIX: Register OpenAIService with all required dependencies
                    services.AddSingleton(sp =>
                    {
                        var logger = sp.GetRequiredService<Microsoft.Extensions.Logging.ILogger<Services.OpenAIService>>();
                        return new Services.OpenAIService(openAiClient, openAiDeployment, logger);
                    });

                    // Add RedisCacheService to DI
                    services.AddSingleton<Services.RedisCacheService>();
                })
                .Build();

            host.Run();
        }
    }
}
