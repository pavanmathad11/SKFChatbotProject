using System;
using System.Net;
using Azure;
using Azure.AI.OpenAI;
using StackExchange.Redis;
using System.Threading.Tasks;

namespace GenAIChatBot.Services
{
    public class RedisCacheService
    {
        private readonly IDatabase _db;

        public RedisCacheService()
        {
            var connString = $"{Environment.GetEnvironmentVariable("REDIS_HOST")},ssl=True,password={Environment.GetEnvironmentVariable("REDIS_PASSWORD")}";
            var connection = ConnectionMultiplexer.Connect(connString);
            _db = connection.GetDatabase();
        }

        public async Task<string> GetCachedResponse(string key)
        {
            return await _db.StringGetAsync(key);
        }

        public async Task SetCachedResponse(string key, string value, int ttlSeconds = 3600)
        {
            await _db.StringSetAsync(key, value, TimeSpan.FromSeconds(ttlSeconds));
        }
    }
}
