using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text.Json;
using Azure.AI.OpenAI;
using GenAIChatBot.Models;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace GenAIChatBot.Services
{
    public class OpenAIService
    {
        private readonly OpenAIClient _client;
        private readonly string _deployment;
        private readonly ILogger<OpenAIService> _logger;

        public OpenAIService(OpenAIClient client, string deployment, ILogger<OpenAIService> logger)
        {
            _client = client;
            _deployment = deployment;
            _logger = logger;
        }

        public async Task<string> GetAnswerAsync(ExtractedQuery query)
        {
            if (string.IsNullOrEmpty(query.Designation) || string.IsNullOrEmpty(query.Attribute))
                return "Sorry, I couldn't understand the bearing designation or attribute.";

            var filePath = Path.Combine("data", $"{query.Designation}.json");
            if (!File.Exists(filePath))
                return $"Sorry, I couldn't find data for bearing {query.Designation}.";

            var jsonString = await File.ReadAllTextAsync(filePath);
            var json = JsonDocument.Parse(jsonString).RootElement;

            string[] sections = { "dimensions", "properties", "performance", "logistics", "specifications" };
            string normalizedTarget = Normalize(query.Attribute);

            foreach (var sectionName in sections)
            {
                if (!json.TryGetProperty(sectionName, out var section) || section.ValueKind != JsonValueKind.Array)
                    continue;

                foreach (var item in section.EnumerateArray())
                {
                    if (item.TryGetProperty("name", out var nameProp))
                    {
                        string name = nameProp.GetString() ?? "";
                        if (IsMatch(normalizedTarget, Normalize(name)))
                        {
                            string value = item.GetProperty("value").ToString();
                            string unit = item.TryGetProperty("unit", out var unitProp) ? $" {unitProp.GetString()}" : "";
                            return $"The {name} of the {query.Designation} bearing is {value}{unit}.";
                        }
                    }
                }
            }

            return $"Sorry, I couldn't find the attribute \"{query.Attribute}\" for bearing {query.Designation}.";
        }

        public async Task<(string Designation, string Attribute)> ExtractDesignationAndAttributeAsync(string userQuestion, string lastDesignation)
        {
            if (string.IsNullOrWhiteSpace(userQuestion))
            {
                _logger.LogWarning("userQuestion is null or empty.");
                return ("", "");
            }

            string systemPrompt = string.IsNullOrEmpty(lastDesignation)
                ? @"You are a helpful assistant for a bearing catalog. Extract the following from the user's question:
                1. The exact product designation (e.g., '6205', '6205 N', '6301') — spacing and suffixes matter.
                2. The specific bearing attribute being asked about (e.g., 'width', 'coating', 'bore type', 'limiting speed', etc.)

                - If either value is missing or unclear, return it as an empty string.
                - Return only in this JSON format:
                { ""designation"": ""..."", ""attribute"": ""..."" }"
                : $@"You are a helpful assistant for a bearing catalog. Extract the following from the user's question:
                1. The product designation (e.g., '6205', '6205 N') — preserve spacing and suffixes exactly.
                2. The specific bearing attribute (e.g., 'width', 'coating', 'bore type', etc.)

                If the product designation is not mentioned in the question, use this known value: '{lastDesignation}'.

                Return only in this JSON format:
                {{ ""designation"": ""..."", ""attribute"": ""..."" }}";

            var options = new ChatCompletionsOptions
            {
                Messages =
                {
                    new ChatMessage(ChatRole.System, systemPrompt),
                    new ChatMessage(ChatRole.User, userQuestion)
                }
            };

            var result = await _client.GetChatCompletionsAsync(_deployment, options);
            var message = result.Value.Choices[0].Message.Content;

            try
            {
                var parsed = JsonSerializer.Deserialize<Dictionary<string, string>>(message);
                return (parsed.GetValueOrDefault("designation", ""), parsed.GetValueOrDefault("attribute", ""));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to parse OpenAI JSON response: {Message}", message);
                return ("", "");
            }
        }

        private static string Normalize(string input)
        {
            return new string(input
                .ToLowerInvariant()
                .Where(c => char.IsLetterOrDigit(c) || char.IsWhiteSpace(c))
                .ToArray())
                .Trim();
        }

        private static bool IsMatch(string target, string candidate)
        {
            return target == candidate || candidate.Contains(target) || target.Contains(candidate);
        }
    }
}

