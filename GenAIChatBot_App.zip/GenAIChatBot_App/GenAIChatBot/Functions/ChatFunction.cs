using System;
using System.IO;
using System.Threading.Tasks;
using System.Text.Json;
using System.Net;
using GenAIChatBot.Models;
using GenAIChatBot.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace GenAIChatBot.Functions
{
    public class ChatFunction
    {
        private readonly ILogger<ChatFunction> _logger;
        private readonly OpenAIService _openAIService;
        private readonly RedisCacheService _cacheService;

        public ChatFunction(ILogger<ChatFunction> logger, OpenAIService openAIService, RedisCacheService cacheService)
        {
            _logger = logger;
            _openAIService = openAIService;
            _cacheService = cacheService;
        }

        [Function("ChatFunction")]
        public async Task<HttpResponseData> Run([HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequestData req)
        {
            var requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            _logger.LogInformation("Raw request body: {Body}", requestBody);

            var chatRequest = JsonSerializer.Deserialize<ChatRequest>(requestBody);
            _logger.LogInformation("Received request. Question: {Question}, LastDesignation: {LastDesignation}", chatRequest?.Question, chatRequest?.LastDesignation);

            if (chatRequest == null || string.IsNullOrWhiteSpace(chatRequest.Question))
            {
                var badResponse = req.CreateResponse(HttpStatusCode.BadRequest);
                await badResponse.WriteStringAsync("Invalid request: missing question.");
                return badResponse;
            }

            var (designation, attribute) = await _openAIService.ExtractDesignationAndAttributeAsync(chatRequest.Question, chatRequest.LastDesignation);

            if (string.IsNullOrEmpty(designation) || string.IsNullOrEmpty(attribute))
            {
                var badResponse = req.CreateResponse(HttpStatusCode.BadRequest);
                await badResponse.WriteStringAsync("Could not extract designation or attribute.");
                return badResponse;
            }

            var structuredRequest = new ExtractedQuery
            {
                Designation = designation,
                Attribute = attribute
            };

            var cacheKey = $"{designation}:{attribute}";
            var cachedAnswer = await _cacheService.GetCachedResponse(cacheKey);
            if (!string.IsNullOrEmpty(cachedAnswer))
            {
                _logger.LogInformation("✅ Cache hit for {Key}", cacheKey);
                var cachedResponse = req.CreateResponse(HttpStatusCode.OK);
                await cachedResponse.WriteAsJsonAsync(new ChatResponse
                {
                    Answer = cachedAnswer,
                    Designation = designation,
                    FromCache = true
                });
                return cachedResponse;
            }

            // No cache hit — generate answer
            string answer = await _openAIService.GetAnswerAsync(structuredRequest);

            // Cache the answer
            await _cacheService.SetCachedResponse(cacheKey, answer);

            var response = req.CreateResponse(HttpStatusCode.OK);
            await response.WriteAsJsonAsync(new ChatResponse
            {
                Answer = answer,
                Designation = designation,
                FromCache = false
            });
            return response;
        }
    }
}
