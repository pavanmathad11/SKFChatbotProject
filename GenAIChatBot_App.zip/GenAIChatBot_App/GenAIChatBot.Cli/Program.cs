// // using System;
// // using System.Net.Http;
// // using System.Text;
// // using System.Text.Json;
// // using System.Threading.Tasks;

// // class Program
// // {
// //     private static string lastDesignation = null;
// //     private static readonly HttpClient httpClient = new HttpClient();

// //     static async Task Main()
// //     {
// //         Console.WriteLine("🤖 Bearing Assistant Ready. Ask your questions.\nType 'exit' to quit.\n");

// //         while (true)
// //         {
// //             Console.Write("You: ");
// //             var input = Console.ReadLine()?.Trim();

// //             if (string.IsNullOrWhiteSpace(input)) continue;
// //             if (input.Equals("exit", StringComparison.OrdinalIgnoreCase)) break;

// //             var payload = new
// //             {
// //                 question = input,
// //                 lastDesignation = lastDesignation
// //             };

// //             var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

// //             try
// //             {
// //                 var response = await httpClient.PostAsync("http://localhost:7071/api/ChatFunction", content);
// //                 response.EnsureSuccessStatusCode();

// //                 var result = await response.Content.ReadAsStringAsync();
// //                 var answer = JsonDocument.Parse(result).RootElement.GetProperty("answer").GetString();

// //                 Console.WriteLine(answer + "\n");

// //                 // Update lastDesignation if mentioned in response (basic heuristic)
// //                 var detected = ExtractDesignation(answer);
// //                 if (!string.IsNullOrWhiteSpace(detected)) lastDesignation = detected;
// //             }
// //             catch (Exception ex)
// //             {
// //                 Console.WriteLine($"❌ Error: {ex.Message}\n");
// //             }
// //         }

// //         Console.WriteLine("👋 Goodbye!");
// //     }

// //     static string ExtractDesignation(string text)
// //     {
// //         string[] known = { "6205", "6205 N" };
// //         foreach (var d in known)
// //         {
// //             if (text.Contains(d, StringComparison.OrdinalIgnoreCase))
// //                 return d;
// //         }
// //         return null;
// //     }
// // }
// // using System;
// using System.Net.Http;
// using System.Text;
// using System.Text.Json;
// using System.Threading.Tasks;

// class Program
// {
//     private static string lastDesignation = null;
//     private static readonly HttpClient httpClient = new HttpClient();

//     static async Task Main()
//     {
//         Console.WriteLine("🛠️  Bearing Assistant Ready. Ask your questions.\nType 'exit' to quit.\n");

//         while (true)
//         {
//             Console.Write("You: ");
//             var input = Console.ReadLine()?.Trim();

//             if (string.IsNullOrWhiteSpace(input)) continue;
//             if (input.Equals("exit", StringComparison.OrdinalIgnoreCase)) break;

//             var payload = new
//             {
//                 question = input,
//                 lastDesignation = lastDesignation
//             };

//             var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

//             try
//             {
//                 var response = await httpClient.PostAsync("http://localhost:7071/api/ChatFunction", content);
//                 var result = await response.Content.ReadAsStringAsync();

//                 if (!response.IsSuccessStatusCode)
//                 {
//                     Console.WriteLine($"❌ Error: {result}\n");
//                     continue;
//                 }

//                 var json = JsonDocument.Parse(result).RootElement;

//                 string answer = json.GetProperty("Answer").GetString();
//                 lastDesignation = json.TryGetProperty("designation", out var dProp) ? dProp.GetString() : lastDesignation;

//                 Console.WriteLine(answer + "\n");
//             }
//             catch (Exception ex)
//             {
//                 Console.WriteLine($"❌ Failed to process response: {ex.Message}");
//             }
//         }

//         Console.WriteLine("Goodbye!");
//     }
// }
using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

class Program
{
    private static string lastDesignation = null;
    private static readonly HttpClient httpClient = new HttpClient();

    static async Task Main()
    {
        Console.WriteLine("🛠️  Bearing Assistant Ready. Ask your questions.\nType 'exit' to quit.\n");

        while (true)
        {
            Console.Write("You: ");
            var input = Console.ReadLine()?.Trim();

            if (string.IsNullOrWhiteSpace(input)) continue;
            if (input.Equals("exit", StringComparison.OrdinalIgnoreCase)) break;

            var payload = new
            {
                question = input,
                lastDesignation = lastDesignation
            };

            var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

            try
            {
                var response = await httpClient.PostAsync("http://localhost:7071/api/ChatFunction", content);
                var result = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"❌ Error: {result}\n");
                    continue;
                }

                var json = JsonDocument.Parse(result).RootElement;

                // Handle Answer
                if (json.TryGetProperty("Answer", out var answerProp) || json.TryGetProperty("answer", out answerProp))
                {
                    var answer = answerProp.GetString();
                    Console.WriteLine(answer + "\n");
                }
                else
                {
                    Console.WriteLine("❓ Response JSON did not contain 'Answer' field.\n");
                }

                // Handle Designation
                if (json.TryGetProperty("Designation", out var dProp) || json.TryGetProperty("designation", out dProp))
                {
                    var newDesignation = dProp.GetString();
                    if (!string.IsNullOrWhiteSpace(newDesignation))
                        lastDesignation = newDesignation;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Failed to process response: {ex.Message}\n");
            }
        }

        Console.WriteLine("Goodbye!");
    }
}
